                                      Statistical Machine Learning
                                               CSE 575
                                                2022
                                               Team 11

                           Topic : Movie recommendation in cold start scenario

                                            Team members :
                                       Saif Masood (1225248414)
                                      Vishnusai Kandati(1225463759)
                                Gayathri Phani Kumar Kanuri(1225608280)
                                      Devadutt Sanka(1225362138)

------------------------------------------------------------------------------------
Steps To Run the Code
------------------------------------------------------------------------------------
--> Import the code file( i.e., Team11_SML_Final_Project.ipynb ) into collab

--> To install require packages run cell 1

--> To install required dataset run cell 2

--> Execute all the remaining cells to train the model in different scenarios and get the results

        * LightFm with tags and tags+ids in both warm and cold situations
        * CF in both cold and warm situations
